# Atom Beautify Documentation

See [options.md](options.md) for supported beautification options.