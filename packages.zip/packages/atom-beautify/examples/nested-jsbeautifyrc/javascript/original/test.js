function hell() {
console.log('world');
}
