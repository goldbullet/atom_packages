package main

import "fmt"

func main() {
	// Why so much white space?

	fmt.Println("This is a poorly formatted file!")
}
