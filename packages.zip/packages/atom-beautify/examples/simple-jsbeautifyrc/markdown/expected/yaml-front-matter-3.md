---
title: "This is a title!"
name: Derek Worthen
age: young
contact: null
email: "email@domain.com"
address: some location
pets:
  - cat
  - dog
  - bat
match: !<tag:yaml.org,2002:js/regexp> /pattern/gmi
run: !<tag:yaml.org,2002:js/function> "function () {\n   \n}"
---

-   item
-   item
-   item

1.  one
2.  two
3.  three

