module TestModule {
export class A {
constructor(private a: string) {
}
}
export class B extends A {
}
};
