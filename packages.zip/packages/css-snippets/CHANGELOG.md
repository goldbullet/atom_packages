## 0.9.0 - 8-20-15
* Add min-height, min-width, display flex, content, & alternative left

## 0.8.0 - 4-25-15
* Make border radius width values consistent with other snippet types
* Add background size

## 0.7.0 - 4-14-15
* Add package keywords

## 0.6.0 - 4-14-15
* Add vertical-align: middle, fill, width/height: auto, float: none
* Make height's prefix more consistent
* Move breakpoints around to support my workflow better

## 0.5.0 - 1-9-15
* Fixed text-transform

## 0.4.0 - 12-21-14
* Added `!important`

## 0.3.0 - 12-21-14
* Changed prefixes for background rules, they all now start with "bg"
* Removed extra `background-postion` rules, probably not needed
* Added `border-radius`
* Fixed `white-space`

## 0.2.0 - 12-11-14
* Added support for .css.less files (Maxime Grébauval)
* Added `position: static`, `width`, and `height`
* Fixed `background-position` prefixes

## 0.1.0 - 12-06-14
* Added a shit ton of snippets
