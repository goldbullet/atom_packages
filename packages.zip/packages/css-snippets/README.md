# CSS Snippets

###### An Atom Package - [Atom.io](https://atom.io/packages/css-snippets) : [Github](https://github.com/dsandstrom/atom-css-snippets)

Shorthand [snippets](https://atom.io/packages/snippets) for CSS, SCSS, Sass, and Less.  

### Whats Included?
Too many to name, but you can see a [complete list](https://github.com/dsandstrom/atom-css-snippets/blob/master/snippets/css-snippets.cson) on Github.  Or, install the package and view the snippets with Settings View.  Basically, its snippets like `bg` for *background* and `ff` for *font-family*.

### Notes
In Beta, there are probably important CSS rules that I missed or snippets not working correctly.  Issues and Pull Requests are welcome.
