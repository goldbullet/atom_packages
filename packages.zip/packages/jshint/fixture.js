'use strict';

var unicorns = '<3 cake'
