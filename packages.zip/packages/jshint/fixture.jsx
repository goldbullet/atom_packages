var div = React.DOM.div;
var app = <div className="appClass">Hello, React!</div>;
