
<p></p>

<p> </p>

<p></p>
<p> </p>

<p></p>
<p> </p>

<p>{lulz}</p>

var myAwesomeThing = (
  <View foo={[1,2,3]}>{[1,2,3]}</View>
);
