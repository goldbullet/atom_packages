## master
* use the JSON scss-lint formatter for better error reporting and scss-lint >=
  0.39.0 support
* remove `excludedLinters` option in favor of `additionalArguments` option

## 0.0.13
* expose executablePath in settings-view

## 0.0.12
* Parse HTML entity characters in output [#19](https://github.com/AtomLinter/linter-scss-lint/pull/19)

## 0.0.9
* Add support for the .scss-lint.yml config file
