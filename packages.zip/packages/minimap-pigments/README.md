# minimap-pigments package [![Build Status](https://travis-ci.org/abe33/minimap-pigments.svg?branch=master)](https://travis-ci.org/abe33/minimap-pigments)

An Atom plugin to display pigments colors in the Minimap.

![Screenshot](https://github.com/abe33/minimap-pigments/blob/master/screenshot.png?raw=true)
