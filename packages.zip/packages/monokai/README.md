# Monokai theme

A monokai syntax theme for Atom.

Originally converted from the [TextMate](http://www.monokai.nl/blog/wp-content/asdev/Monokai.tmTheme)
theme using the [TextMate bundle converter](http://atom.io/docs/latest/converting-a-text-mate-theme).

![](https://f.cloud.github.com/assets/671378/2265671/d02ebee8-9e85-11e3-9b8c-12b2cb7015e3.png)
